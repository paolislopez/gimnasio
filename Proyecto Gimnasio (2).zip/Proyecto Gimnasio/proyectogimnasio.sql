-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 31-10-2020 a las 04:18:11
-- Versión del servidor: 10.4.14-MariaDB
-- Versión de PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyectogimnasio`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro`
--

CREATE TABLE `registro` (
  `ID` int(20) NOT NULL,
  `Fecha` date DEFAULT NULL,
  `Hora` time DEFAULT NULL,
  `Entrenador` varchar(60) NOT NULL,
  `Cliente` varchar(60) NOT NULL,
  `Telefono` int(20) NOT NULL,
  `Genero` varchar(12) NOT NULL,
  `FechaPago` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `registro`
--

INSERT INTO `registro` (`ID`, `Fecha`, `Hora`, `Entrenador`, `Cliente`, `Telefono`, `Genero`, `FechaPago`) VALUES
(23, '2020-10-27', '17:44:01', 'SELECCIONAR', 'Alexander Herrera', 45025478, 'Masculino', '2020-10-27'),
(379, '2020-10-29', '17:44:01', 'Jorge Torrez', 'Lisbeth Pérez', 53667451, 'Femenino', '2020-10-29'),
(657, '2020-10-28', '14:23:47', 'Ricardo Gutierrez', 'Tatiana Cruz', 25478545, 'Femenino', '2020-10-28'),
(5475, '2020-10-29', '12:52:19', 'Ricardo Gutierrez', 'Enrique López', 25469587, 'Masculino', '2020-10-29');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `registro`
--
ALTER TABLE `registro`
  ADD PRIMARY KEY (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
