package conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import static java.awt.PageAttributes.MediaType.D;
import java.sql.Connection;
import java.sql.PreparedStatement;


public class Manual {
    
    public DefaultTableModel mostrarCliente()
    {
        String []  nombresColumnas = {"id","cliente","telefono","fecha","hora","entrenador","Genero","fechaPago"};
        String [] registros = new String[8];
        
        DefaultTableModel modelo = new DefaultTableModel(null,nombresColumnas);
        
        String sql = "SELECT * FROM registro";
        Connection cn = null;
        PreparedStatement pst = null;
        
        ResultSet rs = null;

        try
        {
            cn = conexion.conectar();
            
            pst = cn.prepareStatement(sql);                        
            
            rs = pst.executeQuery();
            
            while(rs.next())
            {
                registros[0] = rs.getString("id");
                registros[1] = rs.getString("Cliente");
                registros[2] = rs.getString("Telefono");
                registros[3] = rs.getString("Fecha");
                registros[4] = rs.getString("Hora");
                registros[5] = rs.getString("Entrenador");
                registros[6] = rs.getString("Genero");
                registros[7] = rs.getString("fechaPago");
                
                modelo.addRow(registros);
                
            }

        }
        catch(SQLException e)
        {
            
            JOptionPane.showMessageDialog(null,"Error al conectar");
            
        }
        finally
        {
            try
            {
                if (rs != null) rs.close();
                
                if (pst != null) pst.close();
                
                if (cn != null) cn.close();
            }
            catch(SQLException e)
            {
                JOptionPane.showMessageDialog(null,e);
            }
        }
         return modelo;
    }
    
    
public int borrarDatos(String id){
    String sql = "DELETE from registro WHERE id = " + id;
    Connection cn = null;
    PreparedStatement pst = null;
    //ResultSet rs = null;
    int rs = 0;
    
    try {
        cn = conexion.conectar();    
        pst = cn.prepareStatement(sql);                        
        rs = pst.executeUpdate();
        
        if(rs>0){
            JOptionPane.showMessageDialog(null, "Registro eliminado ");  
        }
        
    } catch (Exception e) {
        System.err.println(e.getMessage());
    } finally{
        try
            {               
                if (pst != null) pst.close();
                
                if (cn != null) cn.close();
            }
            catch(SQLException e)
            {
                JOptionPane.showMessageDialog(null,e);
            }
    }
        return rs;
    
}

public DefaultTableModel buscarClientes(String buscar)
    {
        String []  nombresColumnas = {"id","cliente","telefono","fecha","hora","entrenador","Genero","fechaPago"};
        String [] registros = new String[8];
        
        DefaultTableModel modelo = new DefaultTableModel(null,nombresColumnas);
        
        String sql = "SELECT * FROM registro WHERE id LIKE '%"+buscar+"%' OR cliente LIKE '%"+buscar+"%'";
        Connection cn = null;
        PreparedStatement pst = null;
        
        ResultSet rs = null;

        try
        {
            cn = conexion.conectar();
            
            pst = cn.prepareStatement(sql);                        
            
            rs = pst.executeQuery();
            
            while(rs.next())
            {
                registros[0] = rs.getString("id");
                registros[1] = rs.getString("Cliente");
                registros[2] = rs.getString("Telefono");
                registros[3] = rs.getString("Fecha");
                registros[4] = rs.getString("Hora");
                registros[5] = rs.getString("Entrenador");
                registros[6] = rs.getString("Genero");
                registros[7] = rs.getString("fechaPago");
                
                modelo.addRow(registros);
            }
            
           
        }
        catch(SQLException e)
        {
            
            JOptionPane.showMessageDialog(null,"Error al conectar");
            
        }
        finally
        {
            try
            {
                if (rs != null) rs.close();
                
                if (pst != null) pst.close();
                
                if (cn != null) cn.close();
            }
            catch(SQLException e)
            {
                JOptionPane.showMessageDialog(null,e);
            }
        }
         return modelo;
    }

}

