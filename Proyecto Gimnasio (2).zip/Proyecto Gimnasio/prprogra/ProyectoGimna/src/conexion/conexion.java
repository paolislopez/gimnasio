package conexion;
//import com.mysql.jdbc.Connection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class conexion {
  private static Connection con;
    public static Connection conectar(){
        try{
           Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/proyectogimnasio", "root", "");
            //JOptionPane.showMessageDialog(null, "Conexion exitosa");
        }catch (Exception e){
            System.out.println("Error "+e);
        }
        return con;
    }
   
    public static void main(String[] args) {
        conexion cn = new conexion();
        Statement st;
        ResultSet rs;   
    }

    
}
